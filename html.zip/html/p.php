<?php
file_put_contents("output.txt", file_get_contents("php://input"));
?>

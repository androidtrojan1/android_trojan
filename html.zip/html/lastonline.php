<?php
echo(file_get_contents("lastonline.txt"));
?>